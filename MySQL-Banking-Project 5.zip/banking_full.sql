-- =============================
-- BANKING MINI PROJECT (MySQL)
-- =============================

DROP TABLE IF EXISTS transactions;
DROP TABLE IF EXISTS loan;
DROP TABLE IF EXISTS accounts;
DROP TABLE IF EXISTS customers;

CREATE TABLE customers (
    customer_id INT PRIMARY KEY,
    name VARCHAR(100),
    phone VARCHAR(15),
    address VARCHAR(150)
);

CREATE TABLE accounts (
    account_id INT PRIMARY KEY,
    customer_id INT,
    account_type VARCHAR(20),
    balance DECIMAL(10,2),
    FOREIGN KEY (customer_id) REFERENCES customers(customer_id)
);

CREATE TABLE transactions (
    txn_id INT PRIMARY KEY,
    account_id INT,
    txn_type VARCHAR(20),
    amount DECIMAL(10,2),
    txn_date DATE,
    FOREIGN KEY (account_id) REFERENCES accounts(account_id)
);

CREATE TABLE loan (
    loan_id INT PRIMARY KEY,
    customer_id INT,
    loan_amount DECIMAL(10,2),
    status VARCHAR(20),
    FOREIGN KEY (customer_id) REFERENCES customers(customer_id)
);

INSERT INTO customers VALUES
(1, 'Suresh', '9876543210', 'Coimbatore'),
(2, 'Raj', '9123456780', 'Chennai'),
(3, 'Priya', '9756421810', 'Bangalore');

INSERT INTO accounts VALUES
(101, 1, 'Savings', 15000.00),
(102, 2, 'Current', 25000.00),
(103, 3, 'Savings', 18000.00);

INSERT INTO transactions VALUES
(1001, 101, 'Deposit', 5000.00, '2024-05-01'),
(1002, 101, 'Withdrawal', 2000.00, '2024-05-02'),
(1003, 103, 'Deposit', 3000.00, '2024-05-02');

INSERT INTO loan VALUES
(501, 1, 50000.00, 'Approved'),
(502, 2, 75000.00, 'Pending'),
(503, 3, 100000.00, 'Approved');

SELECT * FROM customers;
UPDATE accounts SET balance = balance + 2000 WHERE account_id = 101;
DELETE FROM transactions WHERE txn_id = 1002;

SELECT c.name, a.account_id, a.account_type, a.balance
FROM customers c
JOIN accounts a ON c.customer_id = a.customer_id;

SELECT c.name, t.txn_type, t.amount, t.txn_date
FROM customers c
JOIN accounts a ON c.customer_id = a.customer_id
JOIN transactions t ON a.account_id = t.account_id;

SELECT c.name, l.loan_amount, l.status
FROM customers c
JOIN loan l ON c.customer_id = l.customer_id;

SELECT name
FROM customers
WHERE customer_id IN (
    SELECT a.customer_id
    FROM accounts a
    JOIN transactions t ON a.account_id = t.account_id
    WHERE t.amount > 2000
);
